//
//  LaunchVC.swift
//  ProductCategory
//
//  Created by Satheesh M C on 24/12/20.
//  Copyright © 2020 Self. All rights reserved.
//

import UIKit
import Lottie
class LaunchVC: UIViewController {

    @IBOutlet weak var lottieOverlay: UIView!
     let animationView = AnimationView()
    override func viewDidLoad() {
        super.viewDidLoad()
        let path = Bundle.main.path(forResource: "lottie",
                                           ofType: "json") ?? ""
        let screen = UIScreen.main.bounds.size
        animationView.animation = Animation.filepath(path)
        animationView.frame = CGRect(x:screen.width/2 - 80, y: 80, width: 200, height: 400)
           //animationView.center = self.view.center
        
              animationView.loopMode = .loop
              self.view.addSubview(animationView)
              animationView.play()
         animationView.play(fromProgress: 0,
                            toProgress: 1,
                            loopMode: LottieLoopMode.playOnce,
                            completion: { (finished) in
                             if finished {
                                self.animationView.stop()
                               print("Animation Complete, Start second one")
                                let vc = CategoryVC()
                                self.navigationController?.pushViewController(vc, animated: true)
                             } else {
                               print("Animation cancelled")
                             }
         })
        // Do any additional setup after loading the view.
    }


    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
