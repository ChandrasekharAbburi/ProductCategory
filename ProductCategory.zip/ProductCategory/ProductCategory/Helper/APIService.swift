//
//  APIService.swift
//  ProductCategory
//
//  Created by Satheesh M C on 24/12/20.
//  Copyright © 2020 Self. All rights reserved.
//

import Foundation
class APIService {
    static let cateoryApi = "https://run.mocky.io/v3/7bb58c68-85a7-4cd8-9187-1e477f24ee3a"
    static let productApi = "http://www.mocky.io/v2/5e16d5443000004e00d5616d"
}
