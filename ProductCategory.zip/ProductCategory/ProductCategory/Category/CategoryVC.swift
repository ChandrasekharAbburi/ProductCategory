//
//  CategoryVC.swift
//  ProductCategory
//
//  Created by Satheesh M C on 24/12/20.
//  Copyright © 2020 Self. All rights reserved.
//

import UIKit

class CategoryVC: UIViewController,UICollectionViewDelegate,UICollectionViewDataSource,UICollectionViewDelegateFlowLayout {
    
    @IBOutlet weak var categoryCollectionView: UICollectionView!
    
    var categoryList:CategoryList?
    var id:String?
    override func viewDidLoad() {
        super.viewDidLoad()
        navigationItem.hidesBackButton = true
        let nib = UINib(nibName: "CategoryCell", bundle: nil)
        categoryCollectionView.register(nib, forCellWithReuseIdentifier: "CategoryCell")
        categoryCollectionView.dataSource = self
        categoryCollectionView.delegate = self
        WebService.fetchCategories(completion: handleResponseCallback)
    }
    func handleResponseCallback(success: Bool, data: Data) -> Bool {
           let decoder = JSONDecoder()
          
           do {
               
               let category = try decoder.decode(CategoryList.self, from: data)
                  categoryList = category
            categoryCollectionView.reloadData()
               
           } catch {
               print(error.localizedDescription)
           }
            return true
        }
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return categoryList?.arrayOfCategories?.count ?? 0
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "CategoryCell", for: indexPath) as? CategoryCell
        if let index = categoryList?.arrayOfCategories?[indexPath.row] {
            cell?.categoryImageview.setCustomImage(index.imgURL)
            cell?.categoryName.text = index.name
        }
        return cell!
    }
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        let width = collectionView.bounds.width
        let cellWidth = (width - 20) / 2 // compute your cell width
        return CGSize(width: cellWidth, height: cellWidth)
    }
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
         if let index = categoryList?.arrayOfCategories?[indexPath.row] {
         let vc = ProductVC()
        self.navigationController?.pushViewController(vc, animated: true)
          vc.id = String((index.id!))
        }
    }

}
