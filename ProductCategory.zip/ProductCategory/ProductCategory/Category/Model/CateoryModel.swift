//
//  CateoryModel.swift
//  ProductCategory
//
//  Created by Satheesh M C on 24/12/20.
//  Copyright © 2020 Self. All rights reserved.
//

import Foundation
// MARK: - CategoryList
struct CategoryList: Codable {
    var arrayOfCategories: [ArrayOfCategory]?
}

// MARK: - ArrayOfCategory
struct ArrayOfCategory: Codable {
    var imgURL: String?
    var name, id: String?

    enum CodingKeys: String, CodingKey {
        case imgURL = "imgUrl"
        case name, id
    }
}
