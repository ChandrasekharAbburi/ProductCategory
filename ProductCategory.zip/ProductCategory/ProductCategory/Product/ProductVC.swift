//
//  ProductVC.swift
//  ProductCategory
//
//  Created by Satheesh M C on 24/12/20.
//  Copyright © 2020 Self. All rights reserved.
//

import UIKit
import SCLAlertView
class ProductVC: UIViewController,UICollectionViewDelegate,UICollectionViewDataSource,UICollectionViewDelegateFlowLayout {
 
    

    @IBOutlet weak var productCollectionview: UICollectionView!
    
    
    var productList:[ArrayOfProduct]?
    var id:String?
    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationController?.navigationBar.backItem?.hidesBackButton = false
        let nib = UINib(nibName: "CategoryCell", bundle: nil)
        productCollectionview.register(nib, forCellWithReuseIdentifier: "CategoryCell")
        productCollectionview.dataSource = self
        productCollectionview.delegate = self
        WebService.fetchProducts(completion: handleResponseCallback)
        // Do any additional setup after loading the view.
    }

    func handleResponseCallback(success: Bool, data: Data) -> Bool {
           let decoder = JSONDecoder()
          
           do {
               
               let category = try decoder.decode(ProductList.self, from: data)
                  //productList = category
             if id == "" {
                  
              } else {
                  
                let filteredArray = category.arrayOfProducts?.filter { ($0.category?.contains(self.id ?? ""))!}
              
                productList = filteredArray
              }
            productCollectionview.reloadData()
               
           } catch {
               print(error.localizedDescription)
           }
            return true
        }
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return productList?.count ?? 0
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "CategoryCell", for: indexPath) as? CategoryCell
        if let index = productList?[indexPath.row] {
            cell?.categoryImageview.setCustomImage(index.imgURL)
            cell?.categoryName.text = index.name
        }
        return cell!
    }
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        let width = collectionView.bounds.width
        let cellWidth = (width - 20) / 2 // compute your cell width
        return CGSize(width: cellWidth, height: cellWidth)
    }
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
         if let index = productList?[indexPath.row] {
        let alertViewResponder: SCLAlertViewResponder = SCLAlertView().showSuccess("Product", subTitle: "This is a more descriptive text.")
            alertViewResponder.setTitle(index.name ?? "") // Rename title
            let price = "Price: " + (index.price ?? "")
            let quantity = price + "\n\n" + "Quantity: " + "\(index.quantity ?? 0)"
            alertViewResponder.setSubTitle(price)
            alertViewResponder.setSubTitle(quantity)
        //alertViewResponder.close()
        }
    }
    
   

}
