//
//  ProductModel.swift
//  ProductCategory
//
//  Created by Satheesh M C on 24/12/20.
//  Copyright © 2020 Self. All rights reserved.
//

import Foundation
// MARK: - ProductList
struct ProductList: Codable {
    var arrayOfProducts: [ArrayOfProduct]?
}

// MARK: - ArrayOfProduct
struct ArrayOfProduct: Codable {
    var imgURL: String?
    var name, category: String?
    var quantity: Int?
    var arrayOfProductDescription, price: String?

    enum CodingKeys: String, CodingKey {
        case imgURL = "imgUrl"
        case name, category, quantity
        case arrayOfProductDescription = "description"
        case price
    }
}
