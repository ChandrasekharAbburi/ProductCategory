//
//  Webservice.swift
//  ViperSample
//
//  Created by Thilak kumar on 17/09/19.
//  Copyright © 2019 Thilak kumar. All rights reserved.
//

import Alamofire
import Foundation
import SwiftyJSON

class WebService: NSObject {

    typealias ApiCompletionHandler = ((Bool, Data) -> Bool)
    
    class func jsonSerialize(data:Data) -> String{
        do {
            var value:String = ""
            if let json = try JSONSerialization.jsonObject(with: data, options: []) as? [String: Any] {
                
                if let res = json["value"] as? String {
                    
                    value = res
                }
            }
            return value
        } catch let error as NSError {
            print("Failed to load: \(error.localizedDescription)")
            return "Failed to load"
        }
    }

    class func fetchCategories(completion: ApiCompletionHandler? = nil) {
        SessionManager.sharedInstance.getRequest(url:APIService.cateoryApi, completion: completion)
    }
    class func fetchProducts(completion: ApiCompletionHandler? = nil) {
        SessionManager.sharedInstance.getRequest(url:APIService.productApi, completion: completion)
    }

}



