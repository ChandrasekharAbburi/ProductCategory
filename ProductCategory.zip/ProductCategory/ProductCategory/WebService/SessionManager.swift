//
//  SessionManager.swift
//  ViperSample
//
//  Created by Thilak kumar on 19/09/19.
//  Copyright © 2019 Thilak kumar. All rights reserved.
//

import Alamofire
import Foundation
import SwiftyJSON
import UIKit
//import GradientCircularProgress
class SessionManager {
     let valueField = "application/x-www-form-urlencoded"
     let keyField = "Content-Type"
    static var sharedInstance = SessionManager()
    typealias ApiCompletionHandler = ((Bool, Data) -> Bool) // statuscode, success, json -> bool whether ApiManager should continue to show error message

    func postRequest(url: String,parameter:[String:Any], completion: ApiCompletionHandler? = nil) {
       // LoadingOverlay.show("Loading…")
        //progress.show(message: "Loading...", style: MyStyle())
       if (Reachability.isConnectedToNetwork()) == true {
        let header:HTTPHeaders = [keyField : valueField]
        Alamofire.request(url,method: .post, parameters: parameter,headers:header)
        .responseJSON { response in
            //.validate(contentType: ["application/x-www-form-urlencoded"])
            switch response.result {
            case .success:
                if let data = response.data {
                    print(response.result.value ?? "")
                    completion!(true, data)
                }
                //LoadingOverlay.hide()
                //self.progress.dismiss()
            case let .failure(error):
                completion!(false, response.data ?? Data())
                print("RESPONSE ERROR: \(error)")
                //LoadingOverlay.hide()
                //self.progress.dismiss()
            }
        }
        }
    }
    func getRequest(url: String, completion: ApiCompletionHandler? = nil) {
           //progress.show(message: "Loading...", style: MyStyle())
        if (Reachability.isConnectedToNetwork()) == true {
            LoadingOverlay.show("Loading…")
          Alamofire.request(url,method: .get, parameters:nil,headers:nil)
          .responseJSON { response in
              switch response.result {
              case .success:
                  if let data = response.data {
                      print(response.result.value ?? "")
                      completion!(true, data)
                    
                  }
                 LoadingOverlay.hide()
                 // self.progress.dismiss()
              case let .failure(error):
                  completion!(false, response.data ?? Data())
                  print("RESPONSE ERROR: \(error)")
                LoadingOverlay.hide()
                  //self.progress.dismiss()
              }
          }
        }
      }
    
    
}

extension UIImageView {

    func setCustomImage(_ imgURLString: String?) {
        guard let imageURLString = imgURLString else {
            self.image = UIImage(named: "default.png")
            return
        }
        DispatchQueue.global().async { [weak self] in
            let data = try? Data(contentsOf: URL(string: imageURLString)!)
            DispatchQueue.main.async {
                self?.image = data != nil ? UIImage(data: data!) : UIImage(named: "default.png")
            }
        }
    }
}
